import React from "react";
import Logo from 'D:/reactjs/src/Logo.jpg';
function Header()
{
    return (
<header>
    <img src={Logo} alt="St. Paul's University"/>
    <div className="topleft">
        <ul>
              <li class="staffpotal"><a href="https://staff.spu.ac.ke/" target="_blank">Staff Portal</a></li>
              <li class="studentsportal"><a href="https://students.spu.ac.ke/" target="_blank">Students Portal</a></li>
              <li class="checkmail" target="_blank"><a href="https://www.google.com/a/spu.ac.ke/ServiceLogin?service=mail&passive=true&rm=false&continue=https://mail.google.com/a/spu.ac.ke/&ss=1&ltmpl=default&ltmplcache=2" target="_blank">Check Mail</a></li>
              <li class="elearning"><a href="https://elearning.spu.ac.ke/" title="Distance Learning Mode of Study" target="_blank">E-Learning Portal</a></li>
              <li class="vlearning"><a href="https://vlearning.spu.ac.ke/" title="For Day, Evening, Modular and Weekend Modes of Study" target="_blank">V-Learning Portal</a></li>
              <li class="last"><a href="./VirtualTour" target="_blank">Virtual Tour</a></li>              	
          </ul>
    </div>
    <div className="topright">
        <ul>
            <li><a href="./Research">Research</a> </li>
            <li><a href="./Careers">Careers</a></li>
            <li><a href="./ApplyOnline">Apply Online</a></li>
            <li><a href="./OurBankDetails">Our Bank Details</a></li>             	
          </ul>
    </div>
    </header>
    )
}
export default Header;