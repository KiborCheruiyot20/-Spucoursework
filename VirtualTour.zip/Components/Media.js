import React from 'react';
function Media()
{
    return(
   <div class="module">
		<h3>Media Front Page</h3>
        <h1 class="latestnewsicon">Latest News</h1>
		<div class="module">
			<h3>News Show Pro GK5</h3>
			<div class="Main " id="mmain" data-config="{
				'animation_speed': 400,
				'animation_interval': 5000,
				'animation_function': 'Fx.Transitions.Expo.easeIn',
				'news_column': 3,
				'news_rows': 1,
				'links_columns_amount': 3,
				'links_amount': 3
			}">	
        </div>
				
		<div class="TopInterface">
			<a href="#" class="Prev">Prev</a>
			<a href="#" class="Next">Next</a>
		</div>
	<div class="PageActive">
		<div class="Appointment">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/288-st-paul-s-university-appoints-renowned-theologian-as-3rd-vice-chancellor"  title="St. Paul’s University Appoints Renowned Theologian as 3rd Vice Chancellor" target="_self">St. Paul’s University Appoints Renowned Theologian as 3rd Vice Chancellor</a></h4>
                        <a href="/new/images/Installation.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Installation2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul’s University embraced new leadership with the installation of its 3rd Vice Chancellor, Rev. Prof. James Henry Kombo. Held...</p><a class="readon fright" href="/new/index.php/13-latest-news/288-st-paul-s-university-appoints-renowned-theologian-as-3rd-vice-chancellor" target="_self">Read more</a>							</div>
					<div class="Val">
					    <h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/285-vice-chancellor-s-valedictory-lecture"  title="Vice Chancellor's Valedictory Lecture" target="_self">Vice Chancellor's Valedictory Lecture</a></h4>
                        <a href="/new/images/VC-Valedictory-Lecture.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/VC-Valedictory-Lecture2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Selflessness, character, working towards a society's good were just but a few of the the take homes that participants learned...</p><a class="readon fright" href="/new/index.php/13-latest-news/285-vice-chancellor-s-valedictory-lecture" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/282-announcing-the-august-2020-intake"  title="Announcing the January 2021 Intake" target="_self">Announcing the January 2021 Intake</a></h4>
                        <a href="/new/images/Remote-X-aCCSESS.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Remote-X-aCCSESS2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Every year, students are accorded an opportunity to further their education by enrolling for any of the intakes as guided...</p><a class="readon fright" href="/new/index.php/13-latest-news/282-announcing-the-august-2020-intake" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArtPage nspCol20">
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/278-spu-ranked-the-best-private-university-in-kenya"  title="SPU Ranked the best Private University in Kenya" target="_self">SPU Ranked the best Private University in Kenya</a></h4>
                        <a href="/new/images/UniRank-story.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/UniRank-story2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Identified with a customer-centric organization culture, highly qualified dedicated staff and holistic development of individuals, the renowned center of excellence...</p><a class="readon fright" href="/new/index.php/13-latest-news/278-spu-ranked-the-best-private-university-in-kenya" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/277-communication-on-the-may-august-semester-from-the-office-of-deputy-vice-chancellor-academics"  title="Communication to Lecturers on the May - August Semester from the Office of the Deputy Vice Chancellor - Academics" target="_self">Communication to Lecturers on the May - August Semester from the Office of the Deputy Vice Chancellor - Academics</a></h4>
                        <a href="/new/images/May-Intake-2020.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/May-Intake-20202N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The Deputy Vice Chancellor- Academic released an update on the status of the academic affairs in the University with respect...</p><a class="readon fright" href="/new/index.php/13-latest-news/277-communication-on-the-may-august-semester-from-the-office-of-deputy-vice-chancellor-academics" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/276-announcing-the-may-2020-intake"  title="Announcing the May 2020 Intake" target="_self">Announcing the May 2020 Intake</a></h4>
                        <a href="/new/images/May-Intake-2020.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/May-Intake-20202N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Every year, students are accorded an opportunity to further their education by enrolling for any of the intakes as guided...</p><a class="readon fright" href="/new/index.php/13-latest-news/276-announcing-the-may-2020-intake" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArtPage nspCol20">
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/275-spu-library-spurs-continuity-in-learning"  title="SPU Library Spurs Continuity in Learning Amid Anxiety over COVID-19" target="_self">SPU Library Spurs Continuity in Learning Amid Anxiety over COVID-19</a></h4>
                        <a href="/new/images/Remote-X-aCCSESS.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Remote-X-aCCSESS2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Charles Darwin, a famous scientist once stated that it is not the strongest of the species that survives, nor the...</p><a class="readon fright" href="/new/index.php/13-latest-news/275-spu-library-spurs-continuity-in-learning" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/274-peer-counselors-release-a-special-edition-on-covid-19"  title="Peer Counselors Release a Special Edition on Covid-19" target="_self">Peer Counselors Release a Special Edition on Covid-19</a></h4>
                        <a href="/new/images/Coronavirus-thumb.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Coronavirus-thumb2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

With an origin of the Chinese Wuhan City, the deadly corona virus (Covid-19) has spread all over the world and...</p><a class="readon fright" href="/new/index.php/13-latest-news/274-peer-counselors-release-a-special-edition-on-covid-19" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/273-spu-shines-at-kusa-natiomal-play-offs"  title="SPU Shines at KUSA National Play-offs" target="_self">SPU Shines at KUSA National Play-offs</a></h4>
                        <a href="/new/images/KUSA-thumb.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/KUSA-thumb2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul’s University teams ones again made us proud during the KUSA national play-offs for indoor games held in Meru...</p><a class="readon fright" href="/new/index.php/13-latest-news/273-spu-shines-at-kusa-natiomal-play-offs" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArtPage nspCol20">
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/272-spu-hosts-koitalel-arap-samoei-university-for-benchmarking-on-distance-e-learning"  title="Koitalel Arap Samoei University Benchmarks on Distance &amp; E-Learning " target="_self">Koitalel Arap Samoei University Benchmarks on Distance &amp; E-Learning </a></h4>
                        <a href="/new/images/Koitalel-thumb.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Koitalel-thumb2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul’s University hosted Koitalel Arap Samoei University’s senior management for a bench marking session on Distance &amp; E-learning. The...</p><a class="readon fright" href="/new/index.php/13-latest-news/272-spu-hosts-koitalel-arap-samoei-university-for-benchmarking-on-distance-e-learning" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/269-scaling-greater-heights"  title="Scaling Greater Heights" target="_self">Scaling Greater Heights</a></h4>
                        <a href="/new/images/School-of-Theology-thumb.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/School-of-Theology-thumb2N.jpg" alt=""  /></a><p class="nspText tleft fleft">
 

St. Paul’s University once again realized another milestone stipulated in the Strategic Plan (2016-2025) during the ground breaking ceremony...</p><a class="readon fright" href="/new/index.php/13-latest-news/269-scaling-greater-heights" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/262-2nd-nursing-leadership-conference"  title="2nd Nursing Leadership Conference" target="_self">2nd Nursing Leadership Conference</a></h4>
                        <a href="/new/images/Nursing-Conference.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Nursing-Conference2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul’s University in Partnership with the Ministry of Health, Nursing Council of Kenya, Medical Benevolence Foundation (MBF) and Christian...</p><a class="readon fright" href="/new/index.php/13-latest-news/262-2nd-nursing-leadership-conference" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArtPage nspCol20">
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/261-more-accommodation-space-for-students"  title="More Accommodation for Students" target="_self">More Accommodation for Students</a></h4>
                        <a href="/new/images/Tulia-hostels.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Tulia-hostels2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The St. Paul’s University has partnered with Tulia Hostels to increase the accomodation capacity. This has been necessitated by the...</p><a class="readon fright" href="/new/index.php/13-latest-news/261-more-accommodation-space-for-students" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/260-installation-of-the-2nd-university-chancellor"  title="Installation of the 2nd University Chancellor" target="_self">Installation of the 2nd University Chancellor</a></h4>
                        <a href="/new/images/Installation.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Installation2N.jpg" alt="Installation of the second university Chancellor, Prof. Margaret Kobia"  /></a><p class="nspText tleft fleft">

The St. Paul’s University fraternity on Friday 5th October, celebrated installation of the second Chancellor, Prof. Margaret Kobia, the Cabinet...</p><a class="readon fright" href="/new/index.php/13-latest-news/260-installation-of-the-2nd-university-chancellor" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/259-social-media-and-politics-book-launch"  title="Social Media and Political Campaigns in Kenya Book Launch" target="_self">Social Media and Political Campaigns in Kenya Book Launch</a></h4>
                        <a href="/new/images/Social-Media-and-Politics-Thumb.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Social-Media-and-Politics-Thumb2N.jpg" alt=""  /></a>
                        <p class="nspText tleft fleft">

The climax of one of the milestones in Dr. John Ndavula’s scholarly works was realized during a colorful launch of...</p><a class="readon fright" href="/new/index.php/13-latest-news/259-social-media-and-politics-book-launch" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArtPage nspCol20">																	
                    <div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/258-research"  title="Research Seminar - Sharing on the Graduate and Doctoral Journey" target="_self">Research Seminar - Sharing on the Graduate and Doctoral Journey</a></h4>
                        <a href="/new/images/7th-June-Seminar.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/7th-June-Seminar2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The Faculty of Social Sciences will on Thursday 7th June 2018, host a research seminar for Postgraduate Students and Faculty...</p><a class="readon fright" href="/new/index.php/13-latest-news/258-research" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/257-spu-to-host-conference-on-biblical-equity-in-africa"  title="SPU to host Conference on Biblical Equity in Africa" target="_self">SPU to host Conference on Biblical Equity in Africa</a></h4>
                        <a href="/new/images/Beacon-Conference.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Beacon-Conference2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul's University in Collaboration with Mathew 28 Ministries.Inc USA will host an international conference and training on Biblical Equity...</p><a class="readon fright" href="/new/index.php/13-latest-news/257-spu-to-host-conference-on-biblical-equity-in-africa" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/256-st-paul-s-university-kenya-selected-to-host-carnegie-african-diaspora-fellow"  title="St. Paul's University Hosts Carnegie African Diaspora Fellow" target="_self">St. Paul's University Hosts Carnegie African Diaspora Fellow</a></h4>
                        <a href="/new/images/CADFP.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/CADFP2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul’s University, Kenya was selected by the Carnegie African Diaspora Fellowship Program (CADFP) to host an African Diaspora scholar...</p><a class="readon fright" href="/new/index.php/13-latest-news/256-st-paul-s-university-kenya-selected-to-host-carnegie-african-diaspora-fellow" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArtPage nspCol20">
					<div class="nspArt nspCol3">
						<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/255-university-signs-mou-with-kiambu-hospital"  title="University Signs MOU with Kiambu County Hospital" target="_self">University Signs MOU with Kiambu County Hospital</a></h4>
                        <a href="/new/images/MOU-Kiambu-Hospital.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/MOU-Kiambu-Hospital2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The university's top management on Friday 18th May, 2018 signed an MOU with Kiambu County Hospital to offer Health Sciences...</p><a class="readon fright" href="/new/index.php/13-latest-news/255-university-signs-mou-with-kiambu-hospital" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/252-faculty-of-social-sciences-research-seminar"  title="Faculty of Social Sciences Research Seminar" target="_self">Faculty of Social Sciences Research Seminar</a></h4>
                                <a href="/new/images/Foss-Research-Semminar.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Foss-Research-Semminar2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The Faculty of Social Sciences will host a training session on “Conceptualizing a Research Problem in Proposal, Project and Thesis/Dissertation...</p><a class="readon fright" href="/new/index.php/13-latest-news/252-faculty-of-social-sciences-research-seminar" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/250-theology-of-work-workshop"  title="Theology of Work Workshop  " target="_self">Theology of Work Workshop  </a></h4>
                                <a href="/new/images/THEOLOGY-TOW.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/THEOLOGY-TOW2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The faculty of Theology invites you to participate in the Theology of work (ToW) workshop from 1st to 3rd March...</p><a class="readon fright" href="/new/index.php/13-latest-news/250-theology-of-work-workshop" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArtPage nspCol20">
					<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/248-public-lecture-on-christians-of-color-martin-luther-and-ethiopian-christianity"  title="Public Lecture on Christians of Color: Martin Luther and Ethiopian Christianity" target="_self">Public Lecture on Christians of Color: Martin Luther and Ethiopian Christianity</a></h4>
                                <a href="/new/images/Public-lecture.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Public-lecture2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The faculty of Theology will host a public lecture on Thursday, 8th February from 2:00pm - 3.30pm titled Christians of...</p><a class="readon fright" href="/new/index.php/13-latest-news/248-public-lecture-on-christians-of-color-martin-luther-and-ethiopian-christianity" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/237-diploma-in-clinical-medicine-and-surgery"  title="Diploma in Clinical Medicine Intake" target="_self">Diploma in Clinical Medicine Intake</a></h4>
                                <a href="/new/images/Clinical-Medicine-Thumb.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Clinical-Medicine-Thumb2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The School of Health Sciences at St. Paul’s University invites applicants for the March 2018 intake for the diploma in...</p><a class="readon fright" href="/new/index.php/13-latest-news/237-diploma-in-clinical-medicine-and-surgery" target="_self">Read more</a>							</div>									
                   <div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/220-st-paul-s-takes-kusa-volleyball-throne"  title="St. Paul's takes KUSA volleyball throne" target="_self">St. Paul's takes KUSA volleyball throne</a></h4>
                                <a href="/new/images/Volley-ball.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self">
                                <img  class="nspImage" src="/new/images/Volley-ball.jpg" alt=""  /></a>
                                <p class="nspText tleft fleft">

St. Paul's University's volleyball teams are proving to be true champions in the game. The women's team emerged top in...</p><a class="readon fright" href="/new/index.php/13-latest-news/220-st-paul-s-takes-kusa-volleyball-throne" target="_self">Read more</a>							</div>
					</div>
					<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/191-global-entrepreneurship-training-in-east-africa"  title="Global Entrepreneurship Training in East Africa" target="_self">Global Entrepreneurship Training in East Africa</a></h4>
                                <a href="/new/images/GET-Conference.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self">
                                <img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/GET-Conference2N.jpg" alt=""  /></a>
                                <p class="nspText tleft fleft">
                                Where:St. Paul’s University, Kenya
When:22nd- 27th January, 2018
Theme:Innovation &amp; Prosperity through Entrepreneurship
St. Paul’s University will play host to the Global Entrepreneurship...</p><a class="readon fright" href="/new/index.php/13-latest-news/191-global-entrepreneurship-training-in-east-africa" target="_self">Read more</a>							</div>
					<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/190-celebrating-10-years-of-excellence"  title="Celebrating 10 years of excellence!" target="_self">Celebrating 10 years of excellence!</a></h4>
                                <a href="/new/images/10-Years-charter-anniversary.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/10-Years-charter-anniversary2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Building on decades of delivering quality Education, St. Paul’s University celebrates 10 years since its charter. Since the inception as...</p><a class="readon fright" href="/new/index.php/13-latest-news/190-celebrating-10-years-of-excellence" target="_self">Read more</a>							</div>
						<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/188-public-lecture-on-scriptural-reasoning-and-christian-muslim-relations-building-pathways-to-peace-in-times-of-trouble"  title="Public Lecture on Scriptural Reasoning and Christian Muslim Relations - Building Pathways to Peace in Times of Trouble&quot;" target="_self">Public Lecture on Scriptural Reasoning and Christian Muslim Relations - Building Pathways to Peace in Times of Trouble&quot;</a></h4>
                                <a href="/new/images/Lecture.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Lecture2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The Centre for Christian Muslim Relations in Eastleigh &amp;Faculty of Theology invites you to a Public Lecture on Thursday, 28...</p><a class="readon fright" href="/new/index.php/13-latest-news/188-public-lecture-on-scriptural-reasoning-and-christian-muslim-relations-building-pathways-to-peace-in-times-of-trouble" target="_self">Read more</a>							</div>
						</div>
						<div class="nspArtPage nspCol20">
						<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/187-volume-ii-of-african-multidisciplinary-journal-of-research-out"  title="Volume II of African Multidisciplinary Journal of Research out!" target="_self">Volume II of African Multidisciplinary Journal of Research out!</a></h4>
                                <a href="/new/images/journal.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/journal2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Articles for the second issue (December 2017) are being received and the deadline is 15th September, 2017.
The journal is a...</p><a class="readon fright" href="/new/index.php/13-latest-news/187-volume-ii-of-african-multidisciplinary-journal-of-research-out" target="_self">Read more</a>							</div>
						<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/173-upcoming-conference"  title="Upcoming Conference" target="_self">Upcoming Conference</a></h4>
                                <a href="/new/images/Research-Conference-2-3-November-2017.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Research-Conference-2-3-November-20172N.jpg" alt=""  /></a><p class="nspText tleft fleft">

Theme:Strengthening Research and Innovation for Climate Adaptation and Sustainable Development
Date: 2nd to 3rd November 2017
Venue: St. Paul’s University, Limuru Campus
Climate...</p><a class="readon fright" href="/new/index.php/13-latest-news/173-upcoming-conference" target="_self">Read more</a>							</div>
				       <div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/172-anatomy-lab"  title="New anatomy Lab to prepare Clinicians" target="_self">New anatomy Lab to prepare Clinicians</a></h4>
                                <a href="/new/images/Skills-lab.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Skills-lab2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul’s University has long been recognised as a centre of excellence. Recently the programme for clinical medicine was approved...</p><a class="readon fright" href="/new/index.php/13-latest-news/172-anatomy-lab" target="_self">Read more</a>							</div>
								</div>
						<div class="nspArtPage nspCol20">
						<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/11-main-campus-new-cafeteria-is-here"  title="Main Campus’ new cafeteria is here! " target="_self">Main Campus’ new cafeteria is here! </a></h4>
                                <a href="/new/images/Dining-hall1.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Dining-hall12N.jpg" alt=""  /></a><p class="nspText tleft fleft">

As you may have probably noticed, the main campus’ new students’ cafeteria has been under construction since last semester.
The Vice...</p><a class="readon fright" href="/new/index.php/13-latest-news/11-main-campus-new-cafeteria-is-here" target="_self">Read more</a>							</div>
						<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/12-latest-news-3"  title="2nd issue of the African Multidisciplinary Journal now Published " target="_self">2nd issue of the African Multidisciplinary Journal now Published </a></h4>
                                <a href="/new/images/journal.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/journal2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

The second issue of the SPU journal is now out. Our highlights in this include challenges faced by undergraduate students...</p><a class="readon fright" href="/new/index.php/13-latest-news/12-latest-news-3" target="_self">Read more</a>							</div>
						<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/13-latest-news-4"  title="SPU teams rise to claim top spots in the Nairobi KUSA play-offs" target="_self">SPU teams rise to claim top spots in the Nairobi KUSA play-offs</a></h4>
                                <a href="/new/images/volley-ball.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"   target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/volley-ball2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St. Paul's University enmerged top in the KUSA Nairobi play-offs and will represent the university in the National play-offs at...</p><a class="readon fright" href="/new/index.php/13-latest-news/13-latest-news-4" target="_self">Read more</a>							</div>
												</div>
						<div class="nspArtPage nspCol20">
				<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/14-latest-5"  title="University to host South Sudan Ambassador to Kenya" target="_self">University to host South Sudan Ambassador to Kenya</a></h4>
                                <a href="/new/images/sudan-ambassador.jpg" class="nspImageWrapper tleft fleft gkResponsive modal" target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/sudan-ambassador2N.jpg" alt=""  /></a><p class="nspText tleft fleft">

St.Paul's University will on Thursday 6th April host the Sudan Ambassador to Kenya, his excellency Elisadig Abdalla Elias Diab

</p><a class="readon fright" href="/new/index.php/13-latest-news/14-latest-5" target="_self">Read more</a>							
            
					<div class="nspArt nspCol3">
								<h4 class="nspHeader tleft fnone has-image"><a href="/new/index.php/13-latest-news/10-new-anatomy-lab-to-prepare-clinicians"  title="New anatomy Lab to prepare Clinicians" target="_self">New anatomy Lab to prepare Clinicians</a></h4>
                                <a href="/new/images/Skills-lab.jpg" class="nspImageWrapper tleft fleft gkResponsive modal"  target="_self"><img  class="nspImage" src="https://www.spu.ac.ke/new/modules/mod_news_pro_gk5/cache/Skills-lab2N.jpg" alt=""  /></a>
                                <p class="nspText tleft fleft">
St. Paul’s University has long been recognised as a centre of excellence. Recently the programme for clinical medicine was approved...</p><a class="readon fright" href="/new/index.php/13-latest-news/10-new-anatomy-lab-to-prepare-clinicians" target="_self">Read more</a>							</div>
</div>
</div>
                <div>
					<a href="/new/index.php/latest-news" class="readon-button">
						Find More News items											
                    </a>
			    </div>
                <div class="blog" itemscope itemtype="https://schema.org/Blog">
                   <div class="items-leading clearfix">
                       <div class="leading-0"itemprop="blogPost" itemscope itemtype="https://schema.org/BlogPosting"></div>
                   </div>    

                   <div class="page-header">
                       <h2 itemprop="name">
                          <a href="/new/index.php/181-upcoming-events" itemprop="url">Upcoming Events</a>
                       </h2>
                   </div>
                </div>
</div>
);
}
export default Media;