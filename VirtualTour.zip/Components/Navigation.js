import React from 'react';
function Navigation()
{
    return(
<nav class="navigate" role="navigation">
   <div class="navbar">
		<a class="btn-navbar collapsed" data-toggle="collapse" data-target=".nav-collapse">
			 <span class="icon-bar"></span>
			 <span class="icon-bar"></span>
			 <span class="icon-bar"></span>
		</a>
    </div>
    <div class="nav-collapse">
		<ul class="nav menu nav-pills mod-list">
           <li class="item-101 default current active"><a href="/new/index.php" >Home</a></li>
           <li class="item-108 deeper parent"><a href="/new/index.php/about" >About SPU</a>
             <ul class="nav-child unstyled small">
                 <li class="item-154"><a href="/new/index.php/about/our-history" >Our History</a></li>
                 <li class="item-155"><a href="/new/index.php/about/vision-mission" >Vision &amp; Mission</a></li>
                 <li class="item-156"><a href="/new/index.php/about/core-values-objectives" >Core Values &amp; Objectives</a></li>
                 <li class="item-157"><a href="/new/index.php/about/board-of-management" >Board of Management</a></li>
                 <li class="item-158"><a href="/new/index.php/about/university-council" >University Council</a></li>
                 <li class="item-414"><a href="/new/index.php/about/collaborations" >Collaborations</a></li>
             </ul>
            </li>
            <li class="item-119 deeper parent"><a href="/new/index.php/faculties" >Faculties</a>
                <ul class="nav-child unstyled small">
                    <li class="item-159 deeper parent"><a href="/new/index.php/faculties/faculty-of-theology-spu" >Faculty of Theology</a>
                       <ul class="nav-child unstyled small">
                           <li class="item-162"><a href="/new/index.php/faculties/faculty-of-theology-spu/message-the-dean" >Message from the Dean</a></li>
                           <li class="item-163"><a href="/new/index.php/faculties/faculty-of-theology-spu/academic-programmes-theology" >Academic Programmes</a></li>
                           <li class="item-164"><a href="/new/index.php/faculties/faculty-of-theology-spu/faculty" >Faculty</a></li>
                        </ul>
                    </li>
                           <li class="item-160 deeper parent"><a href="/new/index.php/faculties/faculty-of-business" >Faculty of Business</a>
                               <ul class="nav-child unstyled small">
                                  <li class="item-165"><a href="/new/index.php/faculties/faculty-of-business/message-from-the-dean-business" >Message from the Dean</a></li>
                                  <li class="item-166"><a href="/new/index.php/faculties/faculty-of-business/academic-programmes-business" >Academic Programmes</a></li>
                                  <li class="item-167"><a href="/new/index.php/faculties/faculty-of-business/faculty-of-business-faculty" >Faculty</a></li>
                               </ul>
                           </li>
                           <li class="item-161 deeper parent"><a href="/new/index.php/faculties/faculty-of-social-sciences" >Faculty of Social Sciences</a>
                               <ul class="nav-child unstyled small"><li class="item-177"><a href="/new/index.php/faculties/faculty-of-social-sciences/message-from-the-dean-foss" >Message from the Dean</a></li>
                                   <li class="item-178"><a href="/new/index.php/faculties/faculty-of-social-sciences/academic-programmes-foss" >Academic Programmes</a></li>
                                   <li class="item-179"><a href="/new/index.php/faculties/faculty-of-social-sciences/faculty-foss" >Faculty</a></li>
                              </ul>
                          </li>
                </ul>
           </li>
       <li class="item-120 deeper parent"><a href="/new/index.php/academic-programmes" >Academic Programmes</a>
            <ul class="nav-child unstyled small">
                <li class="item-296"><a href="/new/index.php/academic-programmes/postgraduate-programmes" >Postgraduate Programmes</a></li>
                <li class="item-297"><a href="/new/index.php/academic-programmes/undergraduate-programmes" >Undergraduate Programmes</a></li>
                <li class="item-298"><a href="/new/index.php/academic-programmes/diploma-programmes" >Diploma Programmes</a></li>
                <li class="item-299"><a href="/new/index.php/academic-programmes/certificate-programmes" >Certificate Programmes</a></li>
            </ul>
        </li>
        <li class="item-122"><a href="/new/index.php/library" >Library</a></li>
        <li class="item-121 deeper parent"><a href="/new/index.php/registry" >Registry</a>
            <ul class="nav-child unstyled small">
                <li class="item-270"><a href="/new/index.php/registry/academic-calendar-registry" >Academic Calendar</a></li>
                <li class="item-271"><a href="/new/index.php/registry/academic-scholarships" >Academic Scholarships</a></li>
                <li class="item-272"><a href="/new/index.php/registry/admission-regulations" >Admission Regulations</a></li>
                <li class="item-184 deeper parent"><a href="/new/index.php/registry/graduation-ceremony" >Graduation</a>
                    <ul class="nav-child unstyled small">
                        <li class="item-347"><a href="/new/index.php/registry/graduation-ceremony/graduation-speeches" >Graduation Speeches</a></li>
                        <li class="item-348"><a href="/new/index.php/registry/graduation-ceremony/voice-magazine" >Voice Magazine </a></li>
                    </ul>
                </li>
                <li class="item-391"><a href="http://www.spu.ac.ke/old/academic-registry/verify-certificates.html" target="_blank" rel="noopener noreferrer">Verify Certicates</a></li>
            </ul>
        </li>
        <li class="item-123 deeper parent"><a href="#" >Directorates</a>
            <ul class="nav-child unstyled small">
                <li class="item-170 deeper parent"><a href="/new/index.php/directorates/distance-learning" >Distance Learning</a>
                    <ul class="nav-child unstyled small">
                        <li class="item-171"><a href="/new/index.php/directorates/distance-learning/programmes-offered" >Programmes Offered</a></li>
                    </ul>
                </li>
                <li class="item-173 deeper parent"><a href="/new/index.php/directorates/board-of-postgraduate-studies" >Board of Postgraduate Studies</a>
                    <ul class="nav-child unstyled small">
                         <li class="item-174"><a href="/new/index.php/directorates/board-of-postgraduate-studies/message-for-the-director" >Message from the Director</a></li>
                         <li class="item-175"><a href="/new/index.php/directorates/board-of-postgraduate-studies/programmes-offered" >Programmes Offered</a></li>
                         <li class="item-180"><a href="/new/index.php/directorates/board-of-postgraduate-studies/documents" >Documents</a></li>
                         <li class="item-183"><a href="/new/index.php/directorates/board-of-postgraduate-studies/policies" >Policies</a></li>
                    </ul>
                </li>
                <li class="item-401"><a href="/new/index.php/directorates/quality-assurance-directorate" >Quality Assurance Directorate</a></li>
                <li class="item-274 deeper parent"><a href="/new/index.php/directorates/research-directorate" >Research Directorate</a>
                    <ul class="nav-child unstyled small">
                        <li class="item-275"><a href="/new/index.php/directorates/research-directorate/publications" >Publications</a></li>
                        <li class="item-276"><a href="/new/index.php/directorates/research-directorate/conferences" >Conferences</a></li>
                    </ul>
                </li>
                <li class="item-300 deeper parent"><a href="/new/index.php/directorates/spill-ldc" >SPILL &amp; LDC</a>
                    <ul class="nav-child unstyled small">
                        <li class="item-301"><a href="/new/index.php/directorates/spill-ldc/upcoming-trainings" >Upcoming Trainings</a></li>
                    </ul>
                </li>
            </ul>
        </li>
        <li class="item-307 deeper parent"><a href="/new/index.php/student-life" >Student Life</a>
            <ul class="nav-child unstyled small"><li class="item-308"><a href="/new/index.php/student-life/sports" >Sports</a></li>
                <li class="item-309"><a href="/new/index.php/student-life/leisure-and-recreation" >Leisure and Recreation</a></li>
            </ul>
        </li>
        <li class="item-389 deeper parent"><a href="#" >Campuses</a>
            <ul class="nav-child unstyled small">
                <li class="item-185"><a href="http://www.spu.ac.ke/new/nairobi" target="_blank" rel="noopener noreferrer">Nairobi Campus</a></li>
                <li class="item-186"><a href="http://www.spu.ac.ke/new/nakuru" target="_blank" rel="noopener noreferrer">Nakuru Campus</a></li>
                <li class="item-187"><a href="http://www.spu.ac.ke/new/machakos" target="_blank" rel="noopener noreferrer">Machakos Campus</a></li>
            </ul>
        </li>
        <li class="item-124"><a href="/new/index.php/contact-us" >Contact Us</a></li>
       </ul>
	</div>
  </nav>

    );
}
export default Navigation;