import React from 'react';
import prof from 'D:/reactjs/src/prof.jpg';
function Welcome()
{
    return(
        <div class="row-fluid">
				<h3>Welcome to St. Paul's</h3>
					<div class="newsflash">
                        <h1>Welcome to St. Paul's University</h1>
                            <div class="content">
                                <div class="photo"><img src={prof} alt="pro-james-kombo, Vice-Chacellor" />
                                    <ul>
                                        <li>Prof. James Kombo</li>
                                        <li>Vice Chancellor</li>
                                    </ul>
                                </div>
                                <div class="description">
                                    <p>Thank you for your interest to study with us.</p>
                                    <p>St. Paul’s University is a Christian ecumenical institution with students and staff from all over the world. Our mission is to raise the standards of education through holistic learning, in a Christian ecumenical atmosphere that gives room for people of all faiths to find a place of study, research, intellectual and spiritual engagement and growth.</p>
                                    <p>We dare dream, plan and act, as we serve God and humanity. We have continued to make great strides and are ever grateful to all who have been part of our journey. We do not take for granted the high standards of excellence that we see all round us. It has taken genuine willingness of many who have sacrificially given of themselves in extraordinary service. We owe our successes to God and to all who proudly and selflessly carry the distinctive St. Paul’s mark of dedication. <a href="/new/index.php/vice-chancellor-s-message"> Read More</a></p>
                                </div>
                            </div>
                    </div>
	</div>
  
    );
}
export default Welcome;