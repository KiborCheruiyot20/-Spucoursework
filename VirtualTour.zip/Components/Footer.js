import React from 'react';
function Footer()
{
    return(
<footer>
         <div class="btn-group pull-right">
           <button class="btn dropdown-toggle" type="button" id="dropdownMenuButton-181" aria-label="User tools"data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
               <span class="icon-cog" aria-hidden="true"></span>
               <span class="caret" aria-hidden="true"></span>
           </button>
            <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-181">
                <li class="print-icon"> <a href="/new/index.php/181-upcoming-events?tmpl=component&amp;print=1&amp;layout=default" title="Print article < Upcoming Events >" onclick="window.open(this.href,'win2','status=no,toolbar=no,scrollbars=yes,titlebar=no,menubar=no,resizable=yes,width=640,height=480,directories=no,location=no'); return false;" rel="nofollow">			<span class="icon-print" aria-hidden="true"></span>
                 Print	</a> 
                </li>
                <li class="email-icon"> <a href="/new/index.php/component/mailto/?tmpl=component&amp;template=spu&amp;link=802d3e75e8b0f89a57d58cc6e6da18468e0f87fe" title="Email this link to a friend" onclick="window.open(this.href,'win2','width=400,height=450,menubar=yes,resizable=yes'); return false;" rel="nofollow">			<span class="icon-envelope" aria-hidden="true"></span>
                 Email	</a> </li>
           </ul>
        </div>
        <dl class="article-info muted">
            <dt class="article-info-term">
                Details					
            </dt>
           <dd class="createdby" itemprop="author" itemscope itemtype="https://schema.org/Person">
               Written by <span itemprop="name">The Group</span>	</dd>
        </dl>
    <div class="event-holder">
        <div class="upcoming-events">
           <h1 class="events">Upcoming Events</h1>
               <p><div class="moduletable">
                    <h3>DPCalendar Upcoming</h3>
                        No events found		</div>
                </p>
        </div>
    <div class="fb-feeds"><h1 class="upcoming-events">Connect with us</h1>
    </div>
    <div class="twitter-feeds"><h1 class="latestnewsicon"> </h1>
    </div>

      <p class="pull-right">
         <a href="#" id="back-top">
           Back to Top				</a>
      </p>
      <p>
        &copy; 2021 St. Paul's University			
      </p>
      </div>
  </footer>
    )
}
export default Footer;