import React from 'react';
function OurPatners()
{
    return(
    <div class="moduletable">
			<h3>Our Partners</h3>
	                <div class="partners-holder">
                       <h1 class="latestnewsicon">Our Partners</h1>
                      <p>	<div class="moduletable">
							   <h3>Slider CK</h3>
						      <div class="swiper-container swiper-layout-over " id="sliderck134" dir="ltr" data-effect="slide">
	                            <div class="swiper-wrapper">
				                <div class="swiper-slide">
						         <figure class="swiper-img-cont">
				                    <img class="swiper-img" alt="Anglican Church of Kenya" src="/new/images/Partners/Anglican-Church-of-Kenya.jpg" />
			                     </figure>
						         <a class=" swiper-link" href="https://www.ackenya.org/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						          <figure class="swiper-img-cont">
				                    <img class="swiper-img" alt="Presbyterian Church of East Africa" src="/new/images/Partners/B-PCEA.jpg" />
			                      </figure>
						          <a class=" swiper-link" href="http://www.pcea.or.ke/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						           <figure class="swiper-img-cont">
				                       <img class="swiper-img" alt="National Council of Churches of Kenya" src="/new/images/Partners/C-National-Council-of-Churches-of-kenya.jpg" />
			                       </figure>
						           <a class=" swiper-link" href="http://www.ncck.org/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="Methodist Church of Kenya" src="/new/images/Partners/D-Methodist-Church-of-Kenya.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://methodistchurchkenya.org/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="Reformed Church of East Africa" src="/new/images/Partners/E-Reformed-church-of-east-africa.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://www.rca.org/global-mission/missionaries/east-africa-partnership/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="County Government of Kiambu" src="/new/images/Partners/Kiambu-County-Government.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://kiambu.go.ke/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="Mathew 28 Ministries" src="/new/images/Partners/Mathew-28-Ministries.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://www.matthew28ministries.org" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="Medical Benevolence Foundation" src="/new/images/Partners/Medical-Benevolent-Foundation.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://medicalmission.org/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="Ministry of Health Kenya" src="/new/images/Partners/Ministry-of-Health-Kenya.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://www.health.go.ke/" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="National Bank of Kenya" src="/new/images/Partners/National-Bank-of-Kenya.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://nationalbank.co.ke/" target="_blank"></a>		</div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="The Programme for Christian-Muslim Relations in Africa" src="/new/images/Partners/PROCMURA.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://www.procmura.org" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="World Vision" src="/new/images/Partners/World-Vision.jpg" />
			                        </figure>
						            <a class=" swiper-link" href="https://www.wvi.org/kenya" target="_blank"></a>		
                                </div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="" src="/new/images/Partners/AAG.jpg" />
			                        </figure>
								</div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="" src="/new/images/Partners/Arizona-State-University.jpg" />
			                        </figure>
								</div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="" src="/new/images/Partners/CHAK.jpg" />
			                        </figure>
								</div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="" src="/new/images/Partners/Nursing-Council-of-Kenya.jpg" />
			                        </figure>
								</div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="" src="/new/images/Partners/iusdrp.jpg" />
			                        </figure>
								</div>
				                <div class="swiper-slide">
						            <figure class="swiper-img-cont">
				                        <img class="swiper-img" alt="" src="/new/images/Partners/national-nurses-association-of-Kenya.jpg" />
			                        </figure>
								</div>
			                </div>
			                <div class="swiper-button-next"></div>
	                        <div class="swiper-button-prev"></div>
	                    </div>
                    </div>
                </p> 
            </div> 
        </div>  
    );
}
export default OurPatners;