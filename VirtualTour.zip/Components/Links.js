import React from "react";

function Links() 
{  
    return (
<div className="main">
    <div class="university-name">
            <h1>ST. PAUL'S UNIVERSITY</h1>
            <h2>Your University of Choice!</h2>
            <a class="brand pull-left" href="/new/">
            <span class="site-title" title="St. Paul's University">St. Paul's University</span>
            </a> 
    </div>

    <div class="menu">
         <ul>
             <li class="kuccps"><a href="https://spu.co.ke" target="_blank">KUCCPS Students</a></li>
             <li><a href="/new/index.php/tenders">Tenders</a></li>
             <li class="journals"><a href="http://journals.spu.ac.ke/" target="_blank">Journals</a></li>
             <li class="downloads"><a href="/index.php/downloads">Downloads</a></li>
             <li class="blog"><a href="http://www.spu.ac.ke/blog/" target="_blank">Blog</a></li>
        </ul>
    </div>
    
   
        
</div>
);
}
 export default Links; 