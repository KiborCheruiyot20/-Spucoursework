import React from 'react';
function Search()
{
    return(
    <div class="search">
	 <form action="input" method="post" class="form-inline">
		<label for="mod-search-searchword87" class="element-invisible">Search ...</label> 
        <input name="searchword" id="mod-search-searchword87" maxlength="200"  class="inputbox search-query input-medium" type="search" size="20" placeholder="Search ..." />		
        <input type="hidden" name="task" value="search" />
		<input type="hidden" name="option" value="com_search" />
		<input type="hidden" name="Itemid" value="101" />
	 </form>
    </div>
  
    );
}
export default Search;