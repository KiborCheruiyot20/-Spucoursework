import React from 'react';
function Programmes()
{
    return(
       <div class="module">
		    <h3>Academics</h3>
            <div class="content-place">
               <h1 class="academics">Academics</h1>
               <div class="img"><img src="/new/images/Faculties.jpg" alt="faculties" /></div>
               <h2>Faculties</h2>
               <p>Faculty of Theology, Faculty of Business Compuer Science and Communication Studies</p>
               <a href="/new/index.php/our-faculties">Read More</a>
              <div class="img"><img src="/new/images/Academic-Programmes.jpg" alt="academic-programmes" /></div>
            </div>
            <div>
               <h2>Academic Programmes</h2>
               <p>We offer unique postgraduate, undergraduate, diploma and certificate programs. </p>
               <a href="/new/index.php/our-academic-programmes">Read More</a>
               <div class="img"><img src="/new/images/Postgraduate-studies.jpg" alt="postgraduate-studies" /></div>
               <h2>Postgraduate Studies</h2>
               <p>The Board of Postgraduate Studies of St. Paul’s University envisions itself as an efficient Board dedicated</p>
               <a href="/new/index.php/board-of-postgraduate-studies">Read More</a>
               <div class="img"><img src="/new/images/Distance-Learning.jpg" alt="distance-learning" /></div>
               <div>
               <h2>Distance Learning</h2>
               <p>St. Paul’s University rolled out its Distance Learning Academic Programmes in September 2012</p>
               <div><a href="/new/index.php/distance-learning-inner">Read More</a></div>
            </div>
            <div class="content">
            <div class="img"><img src="/new/images/Distance-Learning.jpg" alt="institution-e-resources" /> </div>
            </div>
            <div>
               <h2>E-Resources</h2>
               <p>SPU E-Resources are a gateway to a world of content rich and valuable electronic information resouces.</p>
               <a href="/new/index.php/institution-e-resources">Read More</a>
            </div>
            <div>
                <div class="img"><img src="/new/images/Research.jpg" alt="research" /></div>
                <h2>Research</h2>
                <p>Welcome to the Research Directorate at St. Paul's University. We are home to globally recognized scholars</p>
                <a href="/new/index.php/research">Read More</a>
            </div>
            <div class="content">
                <div class="img"><img src="/new/images/Academic-Calendar.jpg" alt="academic-calendar" /> </div>
                <h2>Academic Calendar</h2>
                <a href="/new/index.php/calendar">Read More</a>
            </div>
            <div class="content">
                <div class="img"><img src="/new/images/Study_at_SPU.jpg" alt="academic-calendar" /> </div>
                <h2>Study at SPU</h2>
                <a href="/new/index.php/study-at-spu">Read More</a></div>
            </div>
        </div>
    );
}
export default Programmes;