import React from 'react';
import ImageAb from 'D:/reactjs/src/ImageAb.jpg';
import ImageB from 'D:/reactjs/src/ImageB.jpg';
import ImageC from 'D:/reactjs/src/ImageC.jpg';
import ImageD from 'D:/reactjs/src/ImageD.jpg';
import ImageE from 'D:/reactjs/src/ImageE.jpg';

function SlideShow()
{
    return(
    
    <div className="slideshow-container">
        
        <div class="mySlides fade">
          <div class="numbertext">1 / 5</div>
          <img src={ImageAb} style={{width:"100%"}}/>
          <div class="text">Caption Text</div>
        </div>
        
        <div class="mySlides fade">
          <div class="numbertext">2 / 5</div>
          <img src={ImageB} style={{width:"100%"}}/>
          <div class="text">Caption Two</div>
        </div>
        
        <div class="mySlides fade">
          <div class="numbertext">3 / 5</div>
          <img src={ImageC} style={{width:"100%"}}/>
          <div class="text">Caption Three</div>
        </div>

        <div class="mySlides fade">
            <div class="numbertext">4 / 5</div>
            <img src={ImageD} style={{width:"100%"}}/>
            <div class="text">Caption Text</div>
          </div>

          <div class="mySlides fade">
            <div class="numbertext">5 / 5</div>
            <img src={ImageE} style={{width:"100%"}}/>
            <div class="text">Caption Text</div>
          </div>
        
        <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
        <a class="next" onclick="plusSlides(1)">&#10095;</a>
        
        
        <div style={{textAlign:"center"}}>
          <span class="dot" onclick="currentSlide(1)"></span> 
          <span class="dot" onclick="currentSlide(2)"></span> 
          <span class="dot" onclick="currentSlide(3)"></span> 
          <span class="dot" onclick="currentSlide(4)"></span> 
          <span class="dot" onclick="currentSlide(5)"></span> 
        </div>
    </div>
    );
}
export default SlideShow;