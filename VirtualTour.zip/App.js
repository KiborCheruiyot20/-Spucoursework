import React from 'react';
import './scss/App.css';
import Header from './Components/Header';
import Links from './Components/Links';
import Navigation from './Components/Navigation';
import Search from './Components/Search';
import SlideShow from './Components/SlideShow';
import Welcome from './Components/Welcome';
import OurPatners from './Components/OurPatners';
import Programmes from './Components/Programmes';
import Media from './Components/Media';
import Footer from './Components/Footer';


function App() {
  return (
    <div>
    <Header/>
    <Links/>
    <Navigation/>
    <Search/>
    <SlideShow/>
    <Welcome/>
    <OurPatners/>
    <Programmes/>
    <Media/>
    <Footer/>
    </div>
  );
}

export default App;
