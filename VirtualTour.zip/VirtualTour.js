import React from "react";

function VirtualTour()
{
    return (
<h1>Hello</h1>
    );
}
export default VirtualTour;